<template>
  <div
    class="space-y-3
           max-h-56
           overflow-y-auto pr-1"
  >
    <div
      v-for="(item, i) in items"
      :key="i"
      class="flex items-start gap-3 sm:items-center sm:gap-4 p-3 border rounded-xl
             hover:border-orange-500 transition"
    >
      <img
        :src="item.image"
        :alt="item.name"
        class="h-14 w-14 sm:h-16 sm:w-16 object-contain bg-white rounded-lg border"
      />

      <div class="flex-1 min-w-0">
        <p class="font-semibold text-sm sm:text-base leading-5 truncate text-slate-900">
          {{ item.name }}
        </p>

        <div class="mt-1 text-xs sm:text-sm text-slate-500 flex flex-wrap gap-x-2 gap-y-1">
          <span>
            SKU:
            <span class="font-semibold text-slate-700">{{ item.sku }}</span>
          </span>
          <span class="hidden sm:inline">•</span>
          <span>
            Qty:
            <span class="font-semibold text-slate-700">{{ item.qty }}</span>
          </span>
          <span class="hidden sm:inline">•</span>
          <span>
            Unit:
            <span class="font-semibold text-slate-700">{{ fmt(item.unitPrice) }}</span>
            FCFA
          </span>
        </div>

        <div class="mt-2 sm:hidden text-sm font-semibold text-slate-900">
          Total: {{ fmt(item.unitPrice * item.qty) }} FCFA
        </div>
      </div>

      <div class="hidden sm:block text-right font-semibold text-slate-900 whitespace-nowrap">
        {{ fmt(item.unitPrice * item.qty) }} FCFA
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  items: { type: Array, required: true },
  fmt: { type: Function, required: true },
})
</script>
